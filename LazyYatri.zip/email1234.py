import smtplib

string_to_send_email="""Greetings Lazy Yatri!

Exploring a solution for your ITCHY FEETS?  

Finding famous place to rendezvous with your beloved?
 
NO WORRIES, you've come to the right place and we're really happy to have you onboard. Stay connected for further information :)

Thank you."""
 
def mail(email):
    gmail=smtplib.SMTP('smtp.gmail.com',587)
    gmail.starttls()
    gmail.login("LazyYatri1234@gmail.com","xdsiqxqgonpiccxi")
    
    gmail.sendmail("LazyYatri1234@gmail.com",str(email),str(string_to_send_email))
    gmail.quit()

mail("yamansharma2004@gmail.com")


